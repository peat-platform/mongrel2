import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import eu.openiict.client.api.AuthorizeApi;
import eu.openiict.client.api.ClientsApi;
import eu.openiict.client.api.CloudletsApi;
import eu.openiict.client.api.ObjectsApi;
import eu.openiict.client.api.SessionApi;
import eu.openiict.client.api.TypesApi;
import eu.openiict.client.api.UsersApi;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.*; // or just those you need

public class Main {
	

    public static void main(String[] args) {    	
    	//Setup Required Client and User for Example
    	setupClient("testClient");
    	registerUser("TestUser","secret");
    	
    	//Get user Session to authorize client
    	Session userSession = login("TestUser","secret");
    	if (userSession == null) {
    		throw new Error("Error getting user Session token");
    	}
    	
    	//get Authorization Token to access OPENi platform
    	Token authToken = authorizeClient("testClient", userSession); 	
    	if (authToken == null) {
    		throw new Error("Error getting Authtoken");
    	}
        // Use AuthToken to get Cloudlet
        OPENiCloudlet cloudletData = getCloudletData(authToken);
        System.out.println(cloudletData);
        
        CreateResponse exampleType = createExampleType();
        System.out.println(exampleType);
        
        ObjectResponse exampleObject = createExampleObject(cloudletData,exampleType);
        System.out.println(exampleObject);
    }

	public static void setupClient(String clientId) {
		//Setup Client API
		ClientsApi clientsapi = new ClientsApi();
		// Ignore ssl cert. (Prevents SSL Cert Error)
		clientsapi.getInvoker().ignoreSSLCertificates(true);
		
		//Prepare ClientId request
		ClientRegisterRequest clientIdReq = new ClientRegisterRequest();
		
		//Set ID for new Client
		clientIdReq.setClientId(clientId);
		
		//Create Client
		try {
			clientsapi.createClient(clientIdReq);
		} catch (ApiException e) {
			if (e.getCode() == 400) {
				System.out.println("Client already exists");
			}
			else {
				e.printStackTrace();
			}
		}
	}
    
    public static void registerUser(String username, String password) {
    	//Setup User API
    	UsersApi usersapi = new UsersApi();
    	
    	//Prepare User registration request
    	UserRegisterRequest userReq = new UserRegisterRequest();
    	
    	//Set name and password for user
    	userReq.setName(username);
    	userReq.setPassword(password);
    	
    	//Create User
    	try {
    		usersapi.createUser(userReq);
		} catch (ApiException e) {
			if (e.getCode() == 400) {
				System.out.println("User already exists");
			}
			else {
				e.printStackTrace();
			}
		}
    }
    
    public static Session login(String username, String password) {
    	//Setup API
    	SessionApi sessionapi = new SessionApi();
    	
    	//Prepare User registration request
    	Credentials creds = new Credentials();
    	
    	//Set login credentials
    	creds.setName(username);
        creds.setPassword(password);
    	
        //Retrieve Session token
    	try {
    		Session session = sessionapi.login(creds);
    		return session;
		} catch (ApiException e) {
			e.printStackTrace();
			return null;
		}
    }
    
    public static Token authorizeClient(String clientId, Session userSession) {
    	//Setup API
    	AuthorizeApi authorizeapi = new AuthorizeApi();
    	
    	//Prepare Authorization request
    	AuthorizationRequest authreq = new AuthorizationRequest();
    	
    	//Set ClientId and Session
    	authreq.setClientId(clientId);
    	authreq.setSession(userSession.getSession());
    	
        //Retrieve Authorization token
    	try {
    		Token token = authorizeapi.authorizeClient(authreq);
    		return token;
		} catch (ApiException e) {
			e.printStackTrace();
			return null;
		}
    }
    
    public static OPENiCloudlet getCloudletData(Token authToken) {
    	//Setup CloudletAPI
    	CloudletsApi cloudletapi = new CloudletsApi();
    	
        //Get Cloudlet
    	try {
    		OPENiCloudlet cloudletData = cloudletapi.getCloudletId(authToken.getToken());
    		return cloudletData;
		} catch (ApiException e) {
			e.printStackTrace();
			return null;
		}
    }
    
    public static CreateResponse createExampleType() {
    	//Setup API
    	TypesApi typeApi = new TypesApi();
    	//Create empty Type
    	OPENiType type = new OPENiType();
    	//Context for single property within type
    	ContextValue property = new ContextValue();
    	property.setId("openi:name");
    	property.setOpeniType("string");
    	//Single Type Property
    	ContextEntry context = new ContextEntry();
    	context.setPropertyName("name");
    	context.setPropertyContext(property);
    	//List of Type Properties
    	List<ContextEntry> typeContext = new ArrayList<ContextEntry>();
    	//Add the property to the list
    	typeContext.add(context);
    	//Add the list to the type
    	type.setContext(typeContext);
    	//Set Type reference as it is a required field
    	type.setReference("Name");
    	
    	//Post Type
    	try {
    		CreateResponse resp = typeApi.createType(type);
    		return resp;
		} catch (ApiException e) {
			e.printStackTrace();
			return null;
		}
    }
    
    
    public static ObjectResponse createExampleObject(OPENiCloudlet cloudlet, CreateResponse type) {
    	//Setup API
    	ObjectsApi objectApi = new ObjectsApi();
    	//Create empty Type
    	OPENiObject object = new OPENiObject();
    	//Set Object Type
    	object.setOpeniType(type.getId());
    	//Create Map for object Data
    	Map data = new HashMap<>();
    	data.put("name", "TestName");    	
    	object.setData(data);
    	
    	//Create Object
    	try {
    		ObjectResponse resp = objectApi.createObject(cloudlet.getId(), object);
    		return resp;
		} catch (ApiException e) {
			e.printStackTrace();
			return null;
		}
    }
    
    
}
