package com.example.dmccarthy.openi_camera_app.tasks;

import android.content.Context;
import android.webkit.WebView;

import java.util.List;

import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.IPermissionsResult;
import eu.openiict.client.model.Permissions;


public class SetPermissionsTask {

   private WebView  webView;
   private Context  context;

   public SetPermissionsTask(WebView webView, Context context){
      this.webView = webView;
      this.context = context;
   }


   public void set(){

      updateWebView("Setting permissions....");

      OPENiAsync.instance().processPermissions(context, "openi_permissions.json", new IPermissionsResult() {
         @Override
         public void onSuccess(List<Permissions> permissions) {
            updateWebView("Permissions Set");
         }

         @Override
         public void onFailure(String message) {
            updateWebView(message);
         }
      });
   }


   private void updateWebView(String result){

      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }
}


