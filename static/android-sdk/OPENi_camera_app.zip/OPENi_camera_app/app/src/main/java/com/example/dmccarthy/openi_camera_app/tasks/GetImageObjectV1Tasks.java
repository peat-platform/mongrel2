package com.example.dmccarthy.openi_camera_app.tasks;

import android.os.AsyncTask;
import android.util.Log;
import android.webkit.WebView;

import com.example.dmccarthy.openi_camera_app.models.ImgCache;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import eu.openiict.client.api.ObjectsApi;
import eu.openiict.client.async.models.IAuthTokenResponse;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.OPENiObject;
import eu.openiict.client.utils.OPENiUtils;


public class GetImageObjectV1Tasks {

   private WebView  webView;
   private ImgCache imgCache;

   public GetImageObjectV1Tasks(WebView webView, ImgCache imgCache){
      this.webView  = webView;
      this.imgCache = imgCache;
   }


   public void getImageObject(){
      updateWebView("Getting Image Object Data..");


      OPENiAsync.getOPENiAsync().getAuthToken(new IAuthTokenResponse() {

         @Override
         public void onSuccess(String authToken) {

            Log.d("GetCloudletAsync", "Cloudlet id:" + authToken);

            new AsyncOperation().execute(authToken);
         }

         @Override
         public void onFailure() {
            Log.d("GetCloudletAsync", "GetCloudletAsync error: ");
         }

      });

   }


   private void updateWebView(String result){

      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }


   private class AsyncOperation extends AsyncTask<String, Void, List<String>> {

      @Override
      protected List<String> doInBackground(String... params) {
         try {
            return getImageObject(params[0]);
         }
         catch (Exception e) {
            e.printStackTrace();
            return null;
         }
      }


      @Override
      protected void onPostExecute(List<String> result) {
         if (null == result){
            updateWebView("Cloudlet doesn't contain any images");
         }
         else{
            final StringBuilder sb  = new StringBuilder();
            imgCache.reset();

            for (String id : result){
               sb.append(id + "<br/>");
               imgCache.addAttachmentId(id);
            }
            updateWebView(sb.toString());
         }
      }


      @Override
      protected void onPreExecute() {

      }

      @Override
      protected void onProgressUpdate(Void... values) {

      }


      private List<String> getImageObject(String cloudletId) throws ApiException, IOException, JSONException {

         final ObjectsApi oApi      = OPENiUtils.getObjectApi();

         Log.d("GetImageObjectTasks", "oAPI " + oApi.getBasePath());
         Log.d("GetImageObjectTasks", "oAPI " + oApi.getBasePath() + "/objects/" + cloudletId + "/" + OPENiUtils.DEFAULT_IMAGES_OBJECT_ID);

         final OPENiObject oo = oApi.getObject(cloudletId, OPENiUtils.DEFAULT_IMAGES_OBJECT_ID, Boolean.FALSE, "");

         if (oo == null) {
            Log.d("GetImageObjectTasks", "Object NULL");
            return null;
         }
         else {
            Log.d("GetImageObjectTasks", oo.toString());

            final JSONObject   data   = OPENiUtils.getObjectData(oo);
            final JSONArray    images = data.getJSONArray("images");
            final List<String> ids    = new LinkedList<String>();

            for (int i = 0; i < images.length(); i++){
               ids.add(images.getString(i));
            }

            return ids;
         }
      }
   }
}


