package com.example.dmccarthy.openi_camera_app.tasks;

import android.util.Log;
import android.webkit.WebView;

import java.util.Collection;

import eu.openiict.client.api.BadgeApi;
import eu.openiict.client.async.models.ICloudletObjectCall;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.common.ApiException;


public class GetBadgesTasks {

   private WebView  webView;

   public GetBadgesTasks(WebView webView){
      this.webView  = webView;
   }


   public void getData(){
      updateWebView("Getting Badge Data..");

      OPENiAsync.getOPENiAsync().getCloudletObject(new ICloudletObjectCall() {

         @Override
         public Object doProcess(String authToken) throws ApiException{

            Log.d("GetBadgesTasks", "Get a");
            final BadgeApi badgeApi = new BadgeApi();
            badgeApi.getInvoker().ignoreSSLCertificates(true);
            Log.d("GetBadgesTasks", "Get b");

            return badgeApi.badgeList(null, null, null, null, authToken);
         }


         @Override
         public void onSuccess(Object obj) {

            Log.d("GetBadgesTasks", "Success");
            Log.d("GetBadgesTasks", obj.toString());

            final StringBuilder sb = new StringBuilder();
            final Collection    oo = (Collection) obj;

            Log.d("GetBadgesTasks", oo.toString());

            for (Object o : oo){
               sb.append(o.toString() + "<br/>");
            }

            updateWebView(sb.toString());
         }


         @Override
         public void onFailure() {
            updateWebView("Failure");
         }
      });

   }


   private void updateWebView(String result){

      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }
}


