package com.example.dmccarthy.openi_camera_app.tasks;

import android.util.Log;
import android.webkit.WebView;

import com.example.dmccarthy.openi_camera_app.models.ImgCache;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedList;
import java.util.List;

import eu.openiict.client.async.models.ICloudletObjectCall;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.OPENiObject;
import eu.openiict.client.utils.OPENiUtils;


public class GetImageObjectV2Tasks {

   private WebView  webView;
   private ImgCache imgCache;

   public GetImageObjectV2Tasks(WebView webView, ImgCache imgCache){
      this.webView  = webView;
      this.imgCache = imgCache;
   }


   public void getImageObject(){
      updateWebView("Getting Image Object Data..");

      OPENiAsync.getOPENiAsync().getCloudletObject(new ICloudletObjectCall() {

         @Override
         public Object doProcess(String authToken) throws ApiException{
            Log.d("AAA", authToken);
            return OPENiUtils.getObjectApi().getObjectByAuthToken(OPENiUtils.DEFAULT_IMAGES_OBJECT_ID, Boolean.FALSE, authToken);
         }


         @Override
         public void onSuccess(Object obj) {

            final OPENiObject oo = (OPENiObject) obj;

            Log.d("GetImageObjectTasks", oo.toString());

            try {
               final JSONObject   data   = OPENiUtils.getObjectData(oo);
               final JSONArray    images;
               images = data.getJSONArray("images");
               final List<String> ids    = new LinkedList<String>();

               final StringBuilder sb  = new StringBuilder();
               imgCache.reset();

               for (int i = 0; i < images.length(); i++){
                  final String id = images.getString(i);
                  sb.append(id + "<br/>");
                  imgCache.addAttachmentId(id);
               }

               updateWebView(sb.toString());
            }
            catch (JSONException e) {
               updateWebView("Error parsing JSON");
            }
         }


         @Override
         public void onFailure() {
            updateWebView("Failure");
         }
      });

   }


   private void updateWebView(String result){

      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }
}


