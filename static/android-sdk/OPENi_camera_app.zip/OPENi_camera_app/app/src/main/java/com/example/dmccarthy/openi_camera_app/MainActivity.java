package com.example.dmccarthy.openi_camera_app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;

import com.example.dmccarthy.openi_camera_app.models.ImgCache;

import eu.openiict.client.permissions.ProcessAppPermissions;

import com.example.dmccarthy.openi_camera_app.tasks.DownloadImgTask;
import com.example.dmccarthy.openi_camera_app.tasks.GetBadgesTasks;
import com.example.dmccarthy.openi_camera_app.tasks.GetImageObjectV2Task;
import com.example.dmccarthy.openi_camera_app.tasks.SetPermissionsTask;
import com.example.dmccarthy.openi_camera_app.tasks.TakePhotoTask;
import com.example.dmccarthy.openi_camera_app.tasks.UploadImgTask;

import java.io.File;

import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.permissions.PermissionsActivity;
import eu.openiict.client.utils.OPENiUtils;

public class MainActivity extends Activity implements View.OnClickListener{

   public static final int REQUEST_IMAGE_CAPTURE = 1;
   public static final int REQUEST_TAKE_PHOTO    = 2;

   private ImgCache            imageCache;

   private UploadImgTask         uploadImgTask;
   private GetImageObjectV2Task  getImageObjectV2Task;
   private DownloadImgTask       downloadImgTask;
   private TakePhotoTask         takePhotoTask;
   private GetBadgesTasks        getBadgesTasks;
   private SetPermissionsTask    setPermissionsTask;


   private Button          getImgObjButton;
   private Button          uploadPicButton;
   private Button          downloadPicButton;
   private Button          getBadgesPicButton;

   private WebView         webView;

   private ImageView       imageView;


   @Override
   public void onClick(View view) {


      Log.d("onClick", "onClick: ");

      imageView.setVisibility(View.INVISIBLE);

      switch (view.getId()) {
         case R.id.get_img_obj:
            Log.d("Attachment", "get_img_obj: ");
            getImageObjectV2Task.getImageObject();
            break;
         case R.id.upload_pic:
            Log.d("Attachment", "upload_pic: ");
            takePhotoTask.savePhoto(this);
            break;
         case R.id.download_pic:
            Log.d("Attachment", "download_pic: ");
            downloadImgTask.downloadImage(imageCache.getNextAttachmentId());
            break;
         case R.id.badges:
            Log.d("Attachment", "set permissions: ");
            //getBadgesTasks.getData();
            setPermissionsTask.set();
            break;
      }

   }


   @Override
   protected void onCreate(Bundle savedInstanceState) {

      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);

      OPENiUtils.ignoreSSLCert(true);

      webView            = (WebView) findViewById(R.id.webView);

      getImgObjButton    = (Button) findViewById(R.id.get_img_obj);
      uploadPicButton    = (Button) findViewById(R.id.upload_pic);
      downloadPicButton  = (Button) findViewById(R.id.download_pic);
      getBadgesPicButton = (Button) findViewById(R.id.badges);

      imageView          = (ImageView) findViewById(R.id.imageView);

      imageCache = new ImgCache();

      uploadImgTask         = new UploadImgTask(webView);
      getImageObjectV2Task = new GetImageObjectV2Task(webView, imageCache);
      downloadImgTask       = new DownloadImgTask(webView, imageView);
      takePhotoTask         = new TakePhotoTask();
      getBadgesTasks        = new GetBadgesTasks(webView);
      setPermissionsTask    = new SetPermissionsTask(webView, this);

      getImgObjButton.setOnClickListener(this);
      uploadPicButton.setOnClickListener(this);
      downloadPicButton.setOnClickListener(this);
      getBadgesPicButton.setOnClickListener(this);

      webView.setWebViewClient(new WebViewClient() {
         @Override
         public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();
         }
      });

      OPENiAsync.init("openi_camera_demo_app", this);
   }


   @Override
   protected void onActivityResult(int requestCode, int resultCode, Intent data) {
      if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
         final Bundle extras = data.getExtras();
         final Bitmap imageBitmap = (Bitmap) extras.get("data");
         imageView.setImageBitmap(imageBitmap);
         imageView.setVisibility(View.VISIBLE);
      }
      else if (requestCode == REQUEST_TAKE_PHOTO && resultCode == RESULT_OK) {
         final String fileName = takePhotoTask.getPhotoLocation();
         final File img        = new File(fileName);
         uploadImgTask.uploadImage(img);
      }
   }


   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      // Inflate the menu; this adds items to the action bar if it is present.
      getMenuInflater().inflate(R.menu.menu_main, menu);
      return true;
   }


   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      // Handle action bar item clicks here. The action bar will
      // automatically handle clicks on the Home/Up button, so long
      // as you specify a parent activity in AndroidManifest.xml.
      int id = item.getItemId();

      //noinspection SimplifiableIfStatement
      if (id == R.id.action_settings) {
         startActivity(new Intent(this, PermissionsActivity.class));
         return true;
      }
      else if (id == R.id.action_logout) {
         OPENiAsync.instance().logout();
         return true;
      }

      return super.onOptionsItemSelected(item);
   }


}
