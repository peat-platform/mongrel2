package com.example.dmccarthy.openi_camera_app.tasks;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.IAuthTokenResponse;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.utils.AttachmentUtils;
import eu.openiict.client.utils.OPENiUtils;


public class DownloadImgTask {

   private WebView   webView;
   private ImageView imageView;


   public DownloadImgTask(WebView webView, ImageView imageView){
      this.webView   = webView;
      this.imageView = imageView;
   }


   public void downloadImage(final String attachmentId){
      if (null == attachmentId){
         updateWebView("Attachment ids list empty");
      }
      else {
         updateWebView("Downloading " + attachmentId);

         OPENiAsync.instance().getAuthToken(new IAuthTokenResponse() {
            @Override
            public void onSuccess(String authToken) {
               new AsyncOperation().execute(authToken, attachmentId);
            }

            @Override
            public void onFailure() {
               updateWebView("Error Downloading " + attachmentId);
            }
         });

      }
   }

   private void updateWebView(String result){
      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }


   private class AsyncOperation extends AsyncTask<String, Void, Bitmap> {


      @Override
      protected Bitmap doInBackground(String... params) {

         try {
            return downloadImg(params[0], params[1]);
         } catch (Exception e) {
            e.printStackTrace();
            return null;
         }
      }


      @Override
      protected void onPostExecute(Bitmap result) {

         if (null == result) {
            updateWebView("Problem Processing Download");
         }
         else {
            Log.d("DownloadImgTask", result.toString());
            updateWebView("Image Downloaded: " + result.getByteCount());
            imageView.setImageBitmap(result);
            imageView.setVisibility(View.VISIBLE);
         }

      }


      @Override
      protected void onPreExecute() {

      }

      @Override
      protected void onProgressUpdate(Void... values) {

      }


      private Bitmap downloadImg(String authToken, String attachmentId) throws ApiException, IOException {

         final AttachmentUtils aUtils = OPENiUtils.getAttachmentUtils();
         final InputStream is         = aUtils.getAttachmentInputStream(authToken, attachmentId);
         final Bitmap myBitmap        = BitmapFactory.decodeStream(is);

         return myBitmap;
      }
   }
}


