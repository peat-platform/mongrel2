package com.example.dmccarthy.openi_camera_app.tasks;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import com.example.dmccarthy.openi_camera_app.MainActivity;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * Created by dmccarthy on 07/11/14.
 */
public class TakePhotoTask {

   private List<String> fileNames;

   public TakePhotoTask() {
      fileNames = new ArrayList<String>();
   }


   public void takePhoto(Activity activity) {
      final Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
      if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {
         activity.startActivityForResult(takePictureIntent, MainActivity.REQUEST_IMAGE_CAPTURE);
      }
   }


   public void savePhoto(Activity activity) {
      final Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

      takePictureIntent.putExtra("aaa", "bbb");

      if (takePictureIntent.resolveActivity(activity.getPackageManager()) != null) {

         File photoFile = null;
         try {
            photoFile = createImageFile();
            Log.d("photoFile", "" + photoFile.getAbsolutePath());
         } catch (IOException e) {
            e.printStackTrace();
         }

         if (photoFile != null) {
            Log.d("photoFile", "" + photoFile.getAbsolutePath());

            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,
                  Uri.fromFile(photoFile));

            activity.startActivityForResult(takePictureIntent, MainActivity.REQUEST_TAKE_PHOTO);
         }
      }
   }


   private File createImageFile() throws IOException {
      // Create an image file name
      final String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
      final String imageFileName = "JPEG_" + timeStamp + "_";
      final File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

      final File image = File.createTempFile(
            imageFileName,  /* prefix */
            ".jpg",         /* suffix */
            storageDir      /* directory */
      );

      fileNames.add(image.getAbsolutePath());

      return image;
   }


   public String getPhotoLocation(){

      final String filename = fileNames.iterator().next();
      fileNames.remove(filename);

      return filename;
   }
}