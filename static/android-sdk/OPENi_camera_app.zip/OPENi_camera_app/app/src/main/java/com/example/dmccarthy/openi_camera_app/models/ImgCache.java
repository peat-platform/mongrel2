package com.example.dmccarthy.openi_camera_app.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;


/**
 * Created by dmccarthy on 07/11/14.
 */
public class ImgCache {
   private List<String>         attachmentIds;
   private ListIterator<String> attachmentIdsIter;

   public ImgCache(){
      attachmentIds = new LinkedList<String>();
   }


   public void reset(){
      attachmentIds.clear();
   }


   public void addAttachmentId(String id){
      attachmentIdsIter = null;
      attachmentIds.add(id);
   }


   public String getNextAttachmentId(){

      if (0 == attachmentIds.size()){
         return null;
      }
      if (null == attachmentIdsIter || !attachmentIdsIter.hasNext()){
         final List<String> rev = new ArrayList<String>( attachmentIds);
         Collections.reverse(rev);
         attachmentIdsIter = rev.listIterator();
      }

      return attachmentIdsIter.next();
   }
}
