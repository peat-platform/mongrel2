package com.example.dmccarthy.openi_camera_app.tasks;

import android.os.AsyncTask;
import android.util.Log;
import android.webkit.WebView;

import java.io.File;
import java.io.IOException;

import eu.openiict.client.api.AttachmentsApi;
import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.IAuthTokenResponse;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.Attachment;
import eu.openiict.client.utils.OPENiUtils;


public class UploadImgTask {

   private WebView webView;

   public UploadImgTask(WebView webView){
      this.webView = webView;
   }


   public void uploadImage(final File img){
      updateWebView("Uploading file..");
      OPENiAsync.instance().getAuthToken(new IAuthTokenResponse() {

         @Override
         public void onSuccess(String authToken) {
            new AsyncOperation().execute(authToken, img);
         }

         @Override
         public void onFailure() {
            updateWebView("Failed upload");
         }
      });
   }


   private void updateWebView(String result){

      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }

   private class AsyncOperation extends AsyncTask<Object, Void, String> {


      @Override
      protected String doInBackground(Object... params) {
         try {
            final String authToken  = (String) params[0];
            final File   file       = (File)   params[1];
            return uploadImg(authToken, file);
         }
         catch (Exception e) {
            e.printStackTrace();
            return "Failed";
         }
      }


      @Override
      protected void onPostExecute(String result) {
         updateWebView(result);
      }


      @Override
      protected void onPreExecute() {

      }

      @Override
      protected void onProgressUpdate(Void... values) {

      }


      private String uploadImg(String authToken, File img) throws ApiException, IOException{

         final AttachmentsApi aApi       = OPENiUtils.getAttachmentApi();

         final Attachment a = aApi.uploadAttachmentWithAuthToken(null, null, img, authToken);

         Log.d("UploadImgTask", "a " + a.getId());

         final String im = a.getId() + " uploaded <br/>";

         Log.d("UploadImgTask", "img " + im);

         return im;
      }

   }
}


