package com.example.dmccarthy.openi_camera_app.tasks;

import android.util.Log;
import android.webkit.WebView;

import com.example.dmccarthy.openi_camera_app.models.ImgCache;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import eu.openiict.client.async.OPENiAsync;
import eu.openiict.client.async.models.IOPENiAPiCall;
import eu.openiict.client.common.ApiException;
import eu.openiict.client.model.OPENiObject;
import eu.openiict.client.utils.OPENiUtils;


public class GetImageObjectV2Task {

   private WebView  webView;
   private ImgCache imgCache;
   private String   message;

   public GetImageObjectV2Task(WebView webView, ImgCache imgCache){
      this.webView  = webView;
      this.imgCache = imgCache;
   }


   public void getImageObject(){

      updateWebView("Getting Image Object Data..");

      OPENiAsync.instance().execOpeniApiCall(new IOPENiAPiCall() {

         @Override
         public Object doProcess(String authToken){
            Log.d("GetImageObjectV2Tasks", authToken);

            try{
               OPENiUtils.getObjectApi().getInvoker().ignoreSSLCertificates(true);
               final OPENiObject o = OPENiUtils.getObjectApi().getObjectByAuthToken(OPENiUtils.DEFAULT_IMAGES_OBJECT_ID, Boolean.FALSE, authToken);

               Log.d("GetImageObjectV2Tasks", "" + o);
               return o;
            }
            catch (ApiException e){
               Log.d("GetImageObjectV2Tasks", e.getMessage());
               message = e.getMessage();
               return null;
            }
         }


         @Override
         public void onSuccess(Object obj) {

            final OPENiObject oo = (OPENiObject) obj;

            Log.d("GetImageObjectTasks", oo.toString());

            try {
               final JSONObject data  = OPENiUtils.getObjectData(oo);
               Log.d("GetImageObjectTasks", "" + data);
               Log.d("GetImageObjectTasks", "" + data.opt("images"));
               Log.d("GetImageObjectTasks", "" + data.optJSONArray("images"));
               final JSONArray images = (JSONArray) data.get("images");
               final List<String> ids = new LinkedList<String>();

               final StringBuilder sb = new StringBuilder();
               imgCache.reset();

               for ( int i = 0; i < images.length(); i++) {
                  final Object id = images.get(i);
                  sb.append(id + "<br/>");
                  imgCache.addAttachmentId(id.toString());
               }

               updateWebView(sb.toString());
            } catch (JSONException e) {
               Log.e("GetImageObjectTasks", e.getMessage());
               updateWebView("Error parsing JSON");
            }
         }


         @Override
         public void onFailure() {
            updateWebView( "Failure: " + message );
         }
      });

   }


   private void updateWebView(String result){

      final String html = "<html><body>" + result + "</body></html>";

      webView.getSettings().setJavaScriptEnabled(true);
      webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
   }
}


