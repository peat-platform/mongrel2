package eu.openi_ict.openiandroidcrud;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import org.peatplatform.client.api.ObjectsApi;
import org.peatplatform.client.async.PeatAsync;
import org.peatplatform.client.async.models.ICreateObjectResult;
import org.peatplatform.client.async.models.IListObjectsResponse;
import org.peatplatform.client.async.models.IPeatAPiCall;
import org.peatplatform.client.async.models.IPeatResponse;
import org.peatplatform.client.common.ApiException;
import org.peatplatform.client.model.ObjectResponse;
import org.peatplatform.client.model.PeatObject;
import org.peatplatform.client.model.PeatObjectList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class MainActivity extends Activity implements View.OnClickListener {

   static final String TAG = "CRUD";

   private Button create;
   private Button read;
   private Button list;
   private Button update;
   private Button delete;

   private PeatObject obj1;
   private PeatObject obj2;

   private ProgressDialog progress;

   private SharedPreferences.Editor editor;
   SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(OPENiAndroidCrud.getAppContext());

   @Override
   protected void onCreate(Bundle savedInstanceState) {

      //Log.i(TAG, getResources().getString(R.string.api_key));
      //Log.i(TAG, getResources().getString(R.string.secret_key));
      //Log.d(TAG, "Starting.......");

      OPENiAndroidCrud.setContext(this);

      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);

      create = (Button) findViewById(R.id.create);
      create.setEnabled(true);
      create.setOnClickListener(this);

      read = (Button) findViewById(R.id.read);
      read.setEnabled(false);
      read.setOnClickListener(this);

      list = (Button) findViewById(R.id.list);
      list.setEnabled(false);
      list.setOnClickListener(this);

      update = (Button) findViewById(R.id.update);
      update.setEnabled(false);
      update.setOnClickListener(this);

      delete = (Button) findViewById(R.id.delete);
      delete.setEnabled(false);
      delete.setOnClickListener(this);

      editor = PreferenceManager.getDefaultSharedPreferences(OPENiAndroidCrud.getAppContext()).edit();
   }

   @Override
   protected void onResume() {
      super.onResume();
      PeatAsync.init(getResources().getString(R.string.api_key), getResources().getString(R.string.secret_key), OPENiAndroidCrud.getAppContext());
   }

   @Override
   public boolean onCreateOptionsMenu(Menu menu) {
      // Inflate the menu; this adds items to the action bar if it is present.
      getMenuInflater().inflate(R.menu.menu_main, menu);
      return true;
   }

   @Override
   public boolean onOptionsItemSelected(MenuItem item) {
      // Handle action bar item clicks here. The action bar will
      // automatically handle clicks on the Home/Up button, so long
      // as you specify a parent activity in AndroidManifest.xml.
      int id = item.getItemId();

      //noinspection SimplifiableIfStatement
      if (id == R.id.action_settings) {
         return true;
      }

      return super.onOptionsItemSelected(item);
   }

   @Override
   public void onClick(View v) {
      progress = new ProgressDialog(this);
      progress.show();
      //Log.d(TAG, "########## CLICK ##########");
      if (v.getId() == create.getId()) {
         createCloudletObject();
         createCloudletObject2();
      } else if (v.getId() == read.getId()) {
         readCloudletObject();
      } else if (v.getId() == list.getId()) {
         listCloudletObjects();
      } else if (v.getId() == update.getId()) {
         updateCloudletObjects();
      } else if (v.getId() == delete.getId()) {
         deleteCloudletObjects();
      } else {
         return;
      }
   }

   private void createCloudletObject() {

      final PeatObject oo = new PeatObject();
      oo.setType("t_078c98b96af6474768d74f916ca70286-163");
      final Map data = new HashMap();
      ArrayList<String> strings = new ArrayList<String>();
      strings.add("Create");
      strings.add("Read");
      strings.add("List");

      data.put("stringArray", strings);

      oo.setData(data);

      PeatAsync.instance(MainActivity.this).createObj(oo, new ICreateObjectResult() {

         @Override
         public void onSuccess(ObjectResponse objectResponse) {
            progress.dismiss();
            //Log.d(TAG, "success");
            //Log.d(TAG, "objectResponse " + objectResponse);
            Toast.makeText(getApplicationContext(), "Created " + objectResponse.getId(), Toast.LENGTH_SHORT).show();
            read.setEnabled(true);
            editor.putString("Object1", objectResponse.getId());
            editor.commit();
         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            //Log.d(TAG, "Error: " + s);
            Toast.makeText(getApplicationContext(), "Failed to Create Object: " + s, Toast.LENGTH_SHORT).show();
         }

      });
   }

   private void createCloudletObject2() {

      final String typeId = "t_078c98b96af6474768d74f916ca70286-163";
      final JSONObject jo = new JSONObject();

      ArrayList<String> strings = new ArrayList<String>();
      strings.add("Search");
      strings.add("Delete");

      try {
         jo.put("stringArray", strings);
      } catch (JSONException e) {
         e.printStackTrace();
      }


      PeatAsync.instance(OPENiAndroidCrud.getAppContext()).createObj(typeId, jo, new ICreateObjectResult() {

         @Override
         public void onSuccess(ObjectResponse objectResponse) {
            progress.dismiss();
            //Log.d(TAG, "success");
            //Log.d(TAG, "objectResponse " + objectResponse);
            editor.putString("Object2", objectResponse.getId());
            editor.commit();
         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            //Log.d(TAG, "Error: " + s);
            Toast.makeText(getApplicationContext(), "Failed to Create Object: " + s, Toast.LENGTH_SHORT).show();
         }


      });
   }


   private void readCloudletObject() {

      PeatAsync.instance(OPENiAndroidCrud.getAppContext()).getObject(prefs.getString("Object1", ""), new IPeatResponse<PeatObject>() {

         @Override
         public void onSuccess(PeatObject PeatObject) {
            progress.dismiss();
            //Log.d(TAG, "success");
            //Log.d(TAG, "objectResponse " + PeatObject);
            obj1 = PeatObject;
            Toast.makeText(getApplicationContext(), "Read: " + PeatObject.toString(), Toast.LENGTH_SHORT).show();
            list.setEnabled(true);
         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            //Log.d(TAG, "Error: " + s);
            Toast.makeText(getApplicationContext(), "Failed to Read Object: "+s, Toast.LENGTH_SHORT).show();
         }
      });
   }

   private void listCloudletObjects() {

      PeatAsync.instance(OPENiAndroidCrud.getAppContext()).listObjects(null, null, null, false, null, null, null, new IListObjectsResponse() {

         @Override
         public void onSuccess(PeatObjectList PeatObjectList) {
            progress.dismiss();

            //Log.d(TAG, "Succeeded");
            //Log.d(TAG, "" + PeatObjectList);
            //Log.d(TAG, "" + PeatObjectList.getMeta());

            String message = "Found " + PeatObjectList.getMeta().getTotalCount() + " objects: ";

            for (PeatObject oo : PeatObjectList.getResult()) {
               message += oo.getId() + "\n ";
            }

            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            update.setEnabled(true);

         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            //Log.d(TAG, "Error: " + s);
            Toast.makeText(getApplicationContext(), "Failed to Get Objects: " + s, Toast.LENGTH_SHORT).show();
         }

      });
   }

   private void updateCloudletObjects() {

      PeatAsync.instance(OPENiAndroidCrud.getAppContext()).execPeatApiCall(new IPeatAPiCall() {
         @Override
         public Object doProcess(String auth) {
            Map data = obj1.getData();
            ArrayList stringArray = (ArrayList) data.get("stringArray");
            stringArray.add("Updated");
            data.put("stringArray", stringArray);
            obj1.setData(data);

            ObjectResponse responce = null;

            try {
               return new ObjectsApi().setObjectByAuthToken(prefs.getString("Object1", ""), obj1, auth);
            } catch (ApiException e) {
               e.printStackTrace();
               return null;
            }
         }

         @Override
         public void onSuccess(Object o) {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Updated: " + o.toString(), Toast.LENGTH_SHORT).show();
            delete.setEnabled(true);
         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            //Log.d(TAG, "Error: " + s);
            Toast.makeText(getApplicationContext(), "Failed to Update Object: " + s, Toast.LENGTH_SHORT).show();
         }
      });
   }

   private void deleteCloudletObjects() {

      PeatAsync.instance(OPENiAndroidCrud.getAppContext()).execPeatApiCall(new IPeatAPiCall() {
         @Override
         public Object doProcess(String auth) {
            Map data = obj1.getData();
            ArrayList stringArray = (ArrayList) data.get("stringArray");
            stringArray.add("Updated");
            data.put("stringArray", stringArray);
            obj1.setData(data);

            ObjectResponse responce = null;

            try {
               return new ObjectsApi().removeObjectByAuth(prefs.getString("Object2", ""), auth);
            } catch (ApiException e) {
               e.printStackTrace();
               return null;
            }
         }

         @Override
         public void onSuccess(Object o) {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Deleted: " + o.toString(), Toast.LENGTH_SHORT).show();
            delete.setEnabled(true);
         }

         @Override
         public void onPermissionDenied() {
            progress.dismiss();
            Toast.makeText(getApplicationContext(), "Permission Denied", Toast.LENGTH_SHORT).show();
         }

         @Override
         public void onFailure(String s) {
            progress.dismiss();
            //Log.d(TAG, "Error: " + s);
            Toast.makeText(getApplicationContext(), "Failed to Delete Object: " + s, Toast.LENGTH_SHORT).show();
         }
      });
   }
}
