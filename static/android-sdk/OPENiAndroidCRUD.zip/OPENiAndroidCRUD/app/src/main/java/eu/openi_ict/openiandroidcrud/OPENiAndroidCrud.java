package eu.openi_ict.openiandroidcrud;

import android.app.Application;
import android.content.Context;

/**
 * Created by dconway on 07/05/15.
 */
public class OPENiAndroidCrud extends Application{

   private static Context context;

   public void onCreate(){
      super.onCreate();
      OPENiAndroidCrud.context = getApplicationContext();
   }

   public static Context getAppContext() {
      return OPENiAndroidCrud.context;
   }

   public static void setContext(Context mContext) {
      OPENiAndroidCrud.context = mContext;
   }

}
